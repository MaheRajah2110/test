﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using TestApp.Models;
using System.Text.Json;

namespace TestApp.Controllers
{
    public class UserController : Controller
    {

        static List<UserViewModel> _userViewModels = new List<UserViewModel>()
        {
            //new UserViewModel(){FirstName="Mahesh", LastName="Rajah"},
        };


        public IActionResult Index()
        {
            IEnumerable<UserViewModel> users = _userViewModels;
            return View(users);
        }

        //Get
        public IActionResult Create()
        {
            return View();
        }

        //Post
        [HttpPost]
        public IActionResult Create(UserViewModel userModel)
        {
            _userViewModels.Add(userModel);
            string strJson = System.Text.Json.JsonSerializer.Serialize<UserViewModel>(userModel);
            Console.WriteLine(strJson);
            System.IO.File.WriteAllText(@"C:\Users\Public\Documents\User.json", strJson);
            return RedirectToAction("Index");
        }

    
    }
}
