﻿namespace TestApp.Models
{
    public class UserViewModel
    {
        [System.ComponentModel.DataAnnotations.StringLength(20, ErrorMessage = "Maximum length of FirstName should be 20 Chars.")]     
        public string? FirstName { get; set; }
        
        [System.ComponentModel.DataAnnotations.StringLength(20, ErrorMessage = "Maximum length of LastName should be 20 Chars.")]
        public string? LastName { get; set; }

       
    }
}
